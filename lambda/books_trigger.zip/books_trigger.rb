require 'json'
def handler(event:, context:)
  p event
  p context
end
