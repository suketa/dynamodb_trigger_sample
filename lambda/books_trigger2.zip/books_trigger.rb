def foo(*args)
  p args
end
